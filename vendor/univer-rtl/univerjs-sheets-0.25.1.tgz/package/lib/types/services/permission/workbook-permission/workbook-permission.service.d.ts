/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Disposable, IPermissionService, IUniverInstanceService } from '@univerjs/core';
import { RangeProtectionRuleModel } from '../../../model/range-protection-rule.model';
import { WorksheetProtectionPointModel, WorksheetProtectionRuleModel } from '../worksheet-permission';
export declare class WorkbookPermissionService extends Disposable {
    private _permissionService;
    private _univerInstanceService;
    private _rangeProtectionRuleModel;
    private _worksheetProtectionRuleModel;
    private _worksheetProtectionPointModel;
    private _unitPermissionInitStateChange;
    unitPermissionInitStateChange$: import("rxjs").Observable<boolean>;
    constructor(_permissionService: IPermissionService, _univerInstanceService: IUniverInstanceService, _rangeProtectionRuleModel: RangeProtectionRuleModel, _worksheetProtectionRuleModel: WorksheetProtectionRuleModel, _worksheetProtectionPointModel: WorksheetProtectionPointModel);
    private _init;
    changeUnitInitState(state: boolean): void;
}
