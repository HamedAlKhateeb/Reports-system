/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ICommandInfo, ICreateUnitOptions, IDisposable, Injector, IWorkbookData, Nullable } from '@univerjs/core';
import type { FWorksheet } from './f-worksheet';
import { FUniver } from '@univerjs/core/facade';
import { FWorkbook } from './f-workbook';
/**
 * @ignore
 */
export interface IFUniverSheetsMixin {
    /**
     * @deprecated use `univerAPI.createWorkbook` instead.
     */
    createUniverSheet(data: Partial<IWorkbookData>): FWorkbook;
    /**
     * Create a new spreadsheet and get the API handler of that spreadsheet.
     * @param {Partial<IWorkbookData>} data The snapshot of the spreadsheet.
     * @param {ICreateUnitOptions} options The options of creating the spreadsheet.
     * @returns {FWorkbook} FWorkbook API instance.
     * @example
     * ```ts
     * const fWorkbook = univerAPI.createWorkbook({ id: 'Sheet1', name: 'Sheet1' });
     * console.log(fWorkbook);
     * ```
     *
     * Add you can make the workbook not as the active workbook by setting options:
     * ```ts
     * const fWorkbook = univerAPI.createWorkbook({ id: 'Sheet1', name: 'Sheet1' }, { makeCurrent: false });
     * console.log(fWorkbook);
     * ```
     */
    createWorkbook(data: Partial<IWorkbookData>, options?: ICreateUnitOptions): FWorkbook;
    /**
     * Get the currently focused Univer spreadsheet.
     * @returns {FWorkbook | null} The currently focused Univer spreadsheet.
     * @example
     * ```ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     * console.log(fWorkbook);
     * ```
     */
    getActiveWorkbook(): FWorkbook | null;
    /**
     * @deprecated use `univerAPI.getActiveWorkbook` instead
     */
    getActiveUniverSheet(): FWorkbook | null;
    /**
     * Get the spreadsheet API handler by the spreadsheet id.
     * @param {string} id The spreadsheet id.
     * @returns {FWorkbook | null} The spreadsheet API instance.
     *
     * @example
     * ```ts
     * const fWorkbook = univerAPI.getUniverSheet('Sheet1');
     * console.log(fWorkbook);
     *
     * const fWorkbook = univerAPI.getWorkbook('Sheet1');
     * console.log(fWorkbook);
     * ```
     */
    getUniverSheet(id: string): FWorkbook | null;
    getWorkbook(id: string): FWorkbook | null;
    /**
     * @deprecated Use `univerAPI.addEvent(univerAPI.Event.UnitCreated, () => {})`
     */
    onUniverSheetCreated(callback: (workbook: FWorkbook) => void): IDisposable;
    /**
     * Get the target of the sheet.
     * @param {string} unitId - The unitId of the sheet.
     * @param {string} subUnitId - The subUnitId of the sheet.
     * @returns {Nullable<{ workbook: FWorkbook; worksheet: FWorksheet }>} - The target of the sheet.
     * @example
     * ```ts
     * const unitId = 'workbook-01';
     * const subUnitId = 'sheet-0001';
     * const target = univerAPI.getSheetTarget(unitId, subUnitId);
     * if (!target) return;
     * const { workbook, worksheet } = target;
     * console.log(workbook, worksheet);
     * ```
     */
    getSheetTarget(unitId: string, subUnitId: string): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    /**
     * Get the target of the sheet.
     * @param {ICommandInfo<object>} commandInfo - The commandInfo of the command.
     * @returns {Nullable<{ workbook: FWorkbook; worksheet: FWorksheet }>} - The target of the sheet.
     * @example
     * ```ts
     * univerAPI.addEvent(univerAPI.Event.CommandExecuted, (event) => {
     *   const { options, ...commandInfo } = event;
     *   const target = univerAPI.getCommandSheetTarget(commandInfo);
     *   if (!target) return;
     *   const { workbook, worksheet } = target;
     *   console.log(workbook, worksheet);
     * });
     * ```
     */
    getCommandSheetTarget(commandInfo: ICommandInfo<object>): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    /**
     * Get the active sheet.
     * @returns {Nullable<{ workbook: FWorkbook; worksheet: FWorksheet }>} The active sheet.
     * @example
     * ```ts
     * const target = univerAPI.getActiveSheet();
     * if (!target) return;
     * const { workbook, worksheet } = target;
     * console.log(workbook, worksheet);
     * ```
     */
    getActiveSheet(): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    /**
     * Set whether to enable synchronize the frozen state to other users in real-time collaboration.
     * @param {boolean} enabled - Whether to enable freeze sync. Default is true.
     * @example
     * ```ts
     * // Disable freeze sync
     * univerAPI.setFreezeSync(false);
     * ```
     */
    setFreezeSync(enabled: boolean): void;
}
export declare class FUniverSheetsMixin extends FUniver implements IFUniverSheetsMixin {
    getCommandSheetTarget(commandInfo: ICommandInfo<object>): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    getSheetTarget(unitId: string, subUnitId: string): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    private _initWorkbookEvent;
    /**
     * @ignore
     */
    _initialize(injector: Injector): void;
    createUniverSheet(data: Partial<IWorkbookData>, options?: ICreateUnitOptions): FWorkbook;
    createWorkbook(data: Partial<IWorkbookData>, options?: ICreateUnitOptions): FWorkbook;
    getActiveWorkbook(): FWorkbook | null;
    getActiveUniverSheet(): FWorkbook | null;
    getUniverSheet(id: string): FWorkbook | null;
    getWorkbook(id: string): FWorkbook | null;
    onUniverSheetCreated(callback: (workbook: FWorkbook) => void): IDisposable;
    getActiveSheet(): Nullable<{
        workbook: FWorkbook;
        worksheet: FWorksheet;
    }>;
    setFreezeSync(enabled: boolean): void;
}
declare module '@univerjs/core/facade' {
    interface FUniver extends IFUniverSheetsMixin {
    }
}
