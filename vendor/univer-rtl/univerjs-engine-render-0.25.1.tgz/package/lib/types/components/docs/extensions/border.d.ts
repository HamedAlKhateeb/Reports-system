/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IScale } from '@univerjs/core';
import type { IDocumentSkeletonGlyph } from '../../../basics/i-document-skeleton-cached';
import type { UniverRenderingContext } from '../../../context';
import { docExtension } from '../doc-extension';
export declare class Border extends docExtension {
    uKey: string;
    Z_INDEX: number;
    private _preBorderStyle;
    private _preBorderColor;
    draw(ctx: UniverRenderingContext, parentScale: IScale, glyph: IDocumentSkeletonGlyph): void;
    clearCache(): void;
    private _createBorderCache;
}
