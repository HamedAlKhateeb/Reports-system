/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDocumentSkeletonLine } from '../../../../../basics/i-document-skeleton-cached';
import { TextDirection } from '@univerjs/core';
/**
 * Apply Unicode bidirectional reordering to every divide in `line`, mutating
 * the glyph order and their `left` offsets so the divide renders correctly
 * when the renderer simply walks `glyphGroup` left-to-right.
 *
 * - For LTR paragraphs we still run bidi: an embedded Hebrew/Arabic run inside
 *   English text must visually reverse, even though the paragraph baseline is
 *   LTR. (Bidi-js auto-detects per paragraph when no explicit direction is
 *   passed.)
 * - For RTL paragraphs we pass `'rtl'` so an all-LTR run still resolves at
 *   level 1 and gets reversed correctly.
 */
export declare function applyBidiReorderToLine(line: IDocumentSkeletonLine, direction?: TextDirection): void;
