/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDocumentRenderConfig, Nullable } from '@univerjs/core';
import type { IDocumentSkeletonPage } from '../../basics/i-document-skeleton-cached';
import type { Transform } from '../../basics/transform';
import type { IViewportInfo } from '../../basics/vector2';
import type { UniverRenderingContext } from '../../context';
import type { IDocumentsConfig, IPageMarginLayout } from './doc-component';
import type { DocumentSkeleton } from './layout/doc-skeleton';
import { VerticalAlign } from '@univerjs/core';
import { DocComponent } from './doc-component';
import './extensions';
export interface IPageRenderConfig {
    page: IDocumentSkeletonPage;
    pageLeft: number;
    pageTop: number;
    ctx: UniverRenderingContext;
}
export interface IDocumentOffsetConfig extends IPageMarginLayout {
    docsLeft: number;
    docsTop: number;
    docsWidth: number;
    docsHeight: number;
    documentTransform: Transform;
}
/**
 * Page-level horizontal offset used by `Documents._horizontalHandler` when
 * painting. Selection/caret code must apply the same offset so the cursor
 * lines up with centered (and right-aligned) cell text.
 */
export declare function computeDocumentPageHorizontalAlignOffset(componentWidth: number, pageContentWidth: number, pagePaddingLeft: number, pagePaddingRight: number, renderConfig?: IDocumentRenderConfig): number;
export declare function computeDocumentPageVerticalAlignOffset(componentHeight: number, pageContentHeight: number, pagePaddingTop: number, pagePaddingBottom: number, verticalAlign?: VerticalAlign): number;
export declare function computeDocumentPageAlignOffset(componentWidth: number, componentHeight: number, page: IDocumentSkeletonPage): {
    x: number;
    y: number;
};
export declare class Documents extends DocComponent {
    private readonly _pageRender$;
    readonly pageRender$: import("rxjs").Observable<IPageRenderConfig>;
    private _drawLiquid;
    constructor(oKey: string, documentSkeleton?: DocumentSkeleton, config?: IDocumentsConfig);
    static create(oKey: string, documentSkeleton?: DocumentSkeleton, config?: IDocumentsConfig): Documents;
    dispose(): void;
    getOffsetConfig(): IDocumentOffsetConfig;
    getEngine(): Nullable<import("../..").Engine>;
    changeSkeleton(newSkeleton: DocumentSkeleton): this;
    protected _draw(ctx: UniverRenderingContext, bounds?: IViewportInfo): void;
    draw(ctx: UniverRenderingContext, bounds?: IViewportInfo): void;
    private _drawTable;
    private _getTableViewport;
    private _getRenderUnitId;
    private _drawBorderBottom;
    private _drawTableCell;
    private _drawTableCellBordersAndBg;
    private _getTableCellSource;
    private _resolveTableCellBorder;
    private _isDrawableTableCellBorder;
    private _drawTableCellBorder;
    private _drawHeaderFooter;
    private _horizontalHandler;
    private _verticalHandler;
    private _startRotation;
    private _resetRotation;
    private _initialDefaultExtension;
}
