/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Returns a Promise that resolves after the specified number of milliseconds.
 * Use this to pause execution for a given duration.
 *
 * @param ms The number of milliseconds to wait before resolving.
 * @returns A Promise that resolves after `ms` milliseconds.
 */
export declare function awaitTime(ms: number): Promise<void>;
/**
 * Returns a Promise that resolves after the specified number of animation frames.
 * Use this to wait for the browser to complete one or more rendering cycles.
 *
 * @param frames The number of animation frames to wait before resolving. Defaults to `1`.
 * @returns A Promise that resolves after `frames` animation frames.
 */
export declare function delayAnimationFrame(frames?: number): Promise<void>;
