/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Disposable, ICommandService, Injector } from '@univerjs/core';
import { ComponentManager } from '../../common/component-manager';
import { IMenuManagerService } from '../../services/menu/menu-manager.service';
import { IShortcutService } from '../../services/shortcut/shortcut.service';
/**
 * This controller add a side panel to the application to display the shortcuts.
 */
export declare class ShortcutPanelController extends Disposable {
    private readonly _menuManagerService;
    constructor(injector: Injector, componentManager: ComponentManager, shortcutService: IShortcutService, _menuManagerService: IMenuManagerService, commandService: ICommandService);
}
