/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable } from '@univerjs/core';
import type { IUniverUIConfig } from '../../config/config';
import type { IUIController } from './ui.controller';
import { Injector, IUniverInstanceService, LifecycleService } from '@univerjs/core';
import { IRenderManagerService } from '@univerjs/engine-render';
import { ComponentManager } from '../../common';
import { ILayoutService } from '../../services/layout/layout.service';
import { IMenuManagerService } from '../../services/menu/menu-manager.service';
import { IUIPartsService } from '../../services/parts/parts.service';
import { SingleUnitUIController } from './ui-shared.controller';
export declare class MobileUIController extends SingleUnitUIController implements IUIController {
    private readonly _config;
    private readonly _componentManager;
    constructor(_config: IUniverUIConfig, injector: Injector, lifecycleService: LifecycleService, renderManagerService: IRenderManagerService, layoutService: ILayoutService, instanceService: IUniverInstanceService, menuManagerService: IMenuManagerService, uiPartsService: IUIPartsService, _componentManager: ComponentManager);
    dispose(): void;
    bootstrap(callback: (contentElement: HTMLElement, containerElement: HTMLElement) => void): IDisposable;
    private _registerComponents;
    private _initBuiltinComponents;
}
