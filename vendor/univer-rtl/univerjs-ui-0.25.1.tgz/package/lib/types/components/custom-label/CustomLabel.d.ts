/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ReactNode } from 'react';
import type { Observable } from 'rxjs';
import type { IMenuSelectorItem } from '../../services/menu/menu';
export type ICustomLabelProps<T = undefined> = {
    className?: string;
    value?: string | number | undefined;
    value$?: Observable<T>;
    onChange?(v: string | number): void;
    title?: ReactNode;
} & Pick<IMenuSelectorItem<unknown>, 'label' | 'icon'>;
/**
 * The component to render toolbar item label and menu item label.
 * @param props
 */
export declare function CustomLabel(props: ICustomLabelProps): import("react/jsx-runtime").JSX.Element;
