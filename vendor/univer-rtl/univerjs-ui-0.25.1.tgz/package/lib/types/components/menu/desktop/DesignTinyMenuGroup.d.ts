/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ComponentType } from 'react';
export interface ITinyMenuItem {
    onClick: () => void;
    className: string;
    Icon: ComponentType<{
        className?: string;
    }>;
    iconClassName?: string;
    key: string;
    active?: boolean;
    tooltip?: string;
}
export interface ITinyMenuGroupProps {
    items: ITinyMenuItem[];
}
export declare function DesignTinyMenuGroup({ items }: ITinyMenuGroupProps): import("react/jsx-runtime").JSX.Element;
