/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable } from '@univerjs/core';
import { Disposable } from '@univerjs/core';
import { createElement, useEffect, useRef } from 'react';
type ComponentFramework = string;
export interface IComponentOptions {
    framework?: ComponentFramework;
}
export interface IComponent<T = any> {
    framework: string;
    component: any;
}
export type ComponentType<T = any> = any;
export type ComponentList = Map<string, IComponent>;
export declare class ComponentManager extends Disposable {
    private _components;
    private _componentsReverse;
    constructor();
    register(name: string, component: ComponentType, options?: IComponentOptions): IDisposable;
    getKey(component: ComponentType): string | undefined;
    reactUtils: {
        createElement: typeof createElement;
        useEffect: typeof useEffect;
        useRef: typeof useRef;
    };
    private _handler;
    setHandler(framework: string, handler: (component: IComponent['component'], name?: string) => any): void;
    get(name: string): any;
    delete(name: string): void;
}
export {};
