/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDropdownProps, ITooltipProps } from '@univerjs/design';
import type { ReactNode } from 'react';
import type { IValueOption } from '../../../services/menu/menu';
export interface ITooltipWrapperRef {
    el: HTMLSpanElement | null;
}
export declare const TooltipWrapper: import("react").ForwardRefExoticComponent<ITooltipProps & import("react").RefAttributes<ITooltipWrapperRef>>;
export declare function DropdownWrapper(props: Omit<Partial<IDropdownProps>, 'overlay'> & {
    overlay: ReactNode;
    align?: 'start' | 'end' | 'center';
}): import("react/jsx-runtime").JSX.Element;
export declare function DropdownMenuWrapper({ menuId, slot, value, options, children, disabled, onOptionSelect, }: {
    menuId: string;
    slot?: boolean;
    value?: string | number;
    options: IValueOption[];
    children: ReactNode;
    disabled?: boolean;
    onOptionSelect: (option: IValueOption) => void;
}): import("react/jsx-runtime").JSX.Element;
