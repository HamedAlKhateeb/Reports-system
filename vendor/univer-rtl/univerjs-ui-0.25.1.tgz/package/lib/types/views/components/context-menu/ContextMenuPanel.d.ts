/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IValueOption } from '../../../services/menu/menu';
import type { IMenuSchema } from '../../../services/menu/menu-manager.service';
interface IContextMenuPanelProps {
    menuType: string;
    menuSessionVersion?: number;
    className?: string;
    activeItemIds?: string[];
    hiddenItemIds?: string[];
    onOptionSelect?: (option: IValueOption) => void;
}
export declare const CONTEXT_MENU_SUBMENU_CLOSE_DELAY = 500;
export declare const CONTEXT_MENU_SUBMENU_PORTAL_ATTR = "data-u-context-menu-submenu";
export declare function hasRenderableContextMenuSchema(menuSchema: IMenuSchema): boolean;
export declare function ContextMenuPanel(props: IContextMenuPanelProps): import("react/jsx-runtime").JSX.Element | null;
export {};
