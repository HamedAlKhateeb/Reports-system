/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { ComponentType } from '../../common/component-manager';
import { Disposable } from '@univerjs/core';
export type ComponentRenderer = () => ComponentType;
type ComponentPartKey = BuiltInUIPart | string;
export declare enum BuiltInUIPart {
    GLOBAL = "global",
    HEADER = "header",
    HEADER_MENU = "header-menu",
    CONTENT = "content",
    FOOTER = "footer",
    LEFT_SIDEBAR = "left-sidebar",
    FLOATING = "floating",
    UNIT = "unit",
    CUSTOM_HEADER = "custom-header",
    CUSTOM_LEFT = "custom-left",
    CUSTOM_RIGHT = "custom-right",
    CUSTOM_FOOTER = "custom-footer",
    TOOLBAR = "toolbar"
}
export interface IUIPartsService {
    componentRegistered$: Observable<ComponentPartKey>;
    uiVisibleChange$: Observable<{
        ui: ComponentPartKey;
        visible: boolean;
    }>;
    registerComponent(part: ComponentPartKey, componentFactory: () => ComponentType): IDisposable;
    getComponents(part: ComponentPartKey): Set<ComponentRenderer>;
    setUIVisible(part: ComponentPartKey, visible: boolean): void;
    isUIVisible(part: ComponentPartKey): boolean;
}
export declare const IUIPartsService: import("@wendellhu/redi").IdentifierDecorator<IUIPartsService>;
export declare class UIPartsService extends Disposable implements IUIPartsService {
    private _componentsByPart;
    private readonly _componentRegistered$;
    readonly componentRegistered$: Observable<string>;
    private readonly _uiVisible;
    private readonly _uiVisibleChange$;
    readonly uiVisibleChange$: Observable<{
        ui: ComponentPartKey;
        visible: boolean;
    }>;
    dispose(): void;
    setUIVisible(part: ComponentPartKey, visible: boolean): void;
    isUIVisible(part: ComponentPartKey): boolean;
    registerComponent<T>(part: ComponentPartKey, componentFactory: () => React.ComponentType<T>): IDisposable;
    getComponents(part: ComponentPartKey): Set<ComponentType>;
}
export {};
