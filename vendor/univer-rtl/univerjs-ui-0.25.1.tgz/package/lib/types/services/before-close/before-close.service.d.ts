/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable } from '@univerjs/core';
import { Disposable } from '@univerjs/core';
import { INotificationService } from '../notification/notification.service';
export interface IBeforeCloseService {
    /**
     * Provide a callback to check if the web page could be closed safely.
     *
     * @param callback The callback to check if the web page could be closed safely.
     * It should return a string to show a message to the user. If the return value is undefined,
     * the web page could be closed safely.
     */
    registerBeforeClose(callback: () => string | undefined): IDisposable;
    /**
     * Provide a callback to be called when the web page is closed.
     *
     * @param callback The callback to be called when the web page is closed.
     */
    registerOnClose(callback: () => void): IDisposable;
}
export declare const IBeforeCloseService: import("@wendellhu/redi").IdentifierDecorator<IBeforeCloseService>;
export declare class DesktopBeforeCloseService extends Disposable implements IBeforeCloseService {
    private readonly _notificationService;
    private _beforeUnloadCallbacks;
    private _onCloseCallbacks;
    private readonly _beforeUnloadHandler;
    private readonly _unloadHandler;
    constructor(_notificationService: INotificationService);
    dispose(): void;
    registerBeforeClose(callback: () => string | undefined): IDisposable;
    registerOnClose(callback: () => void): IDisposable;
    private _init;
}
