/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IAccessor } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { IMenuItem } from './menu';
import { Disposable, IConfigService, Injector } from '@univerjs/core';
import { Subject } from 'rxjs';
export declare const IMenuManagerService: import("@wendellhu/redi").IdentifierDecorator<IMenuManagerService>;
export type ContextMenuQuickLayout = 'icon' | 'tile';
export interface IMenuSchema {
    key: string;
    order: number;
    title?: string;
    contextual?: boolean;
    item?: IMenuItem;
    children?: IMenuSchema[];
    quickLayout?: ContextMenuQuickLayout;
    tiny?: boolean;
}
export interface IMenuManagerService {
    readonly menuChanged$: Observable<void>;
    mergeMenu(source: MenuSchemaType, target?: MenuSchemaType): void;
    appendRootMenu(source: MenuSchemaType): void;
    getMenuByPositionKey(position: string): IMenuSchema[];
    getFlatMenuByPositionKey(position: string): IMenuSchema[];
}
export type MenuSchemaType = {
    order?: number;
    menuItemFactory?: (accessor: IAccessor) => IMenuItem;
    title?: string;
    contextual?: boolean;
    quickLayout?: ContextMenuQuickLayout;
    tiny?: boolean;
} | {
    [key: string]: MenuSchemaType;
};
export declare class MenuManagerService extends Disposable implements IMenuManagerService {
    private readonly _injector;
    private readonly _configService;
    readonly menuChanged$: Subject<void>;
    private _menu;
    constructor(_injector: Injector, _configService: IConfigService);
    dispose(): void;
    /**
     * Merge source menu to target menu recursively
     * @param source
     * @param target default is root menu
     */
    mergeMenu(source: MenuSchemaType, target?: MenuSchemaType): void;
    appendRootMenu(source: MenuSchemaType): void;
    private _buildMenuSchema;
    /**
     * Get menu schema by position key
     * @param key
     * @returns Menu schema array or empty array if not found
     */
    getMenuByPositionKey(key: string): IMenuSchema[];
    /**
     * Get flat menu schema by position key
     * @param key
     * @returns Flat menu schema array or empty array if not found
     */
    getFlatMenuByPositionKey(key: string): IMenuSchema[];
}
