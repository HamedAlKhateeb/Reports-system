/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable } from '@univerjs/core';
import type { ComponentType } from '../../common/component-manager';
import type { IZenZoneService } from './zen-zone.service';
import { BehaviorSubject, ReplaySubject } from 'rxjs';
import { ComponentManager } from '../../common/component-manager';
export declare class DesktopZenZoneService implements IZenZoneService, IDisposable {
    private readonly _componentManager;
    readonly visible$: BehaviorSubject<boolean>;
    readonly componentKey$: ReplaySubject<string>;
    private readonly _temporaryHidden$;
    readonly temporaryHidden$: import("rxjs").Observable<boolean>;
    private _visible;
    get visible(): boolean;
    get temporaryHidden(): boolean;
    constructor(_componentManager: ComponentManager);
    dispose(): void;
    hide(): void;
    show(): void;
    set(key: string, component: ComponentType): IDisposable;
    open(): void;
    close(): void;
}
