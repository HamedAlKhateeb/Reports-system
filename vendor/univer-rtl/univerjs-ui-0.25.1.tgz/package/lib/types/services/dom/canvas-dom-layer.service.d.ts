/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IPosition, Serializable } from '@univerjs/core';
import type { Observable } from 'rxjs';
export interface IFloatDomLayout extends IPosition {
    rotate: number;
    width: number;
    height: number;
    absolute: {
        left: boolean;
        top: boolean;
    };
    opacity?: number;
}
export interface IFloatDom {
    position$: Observable<IFloatDomLayout>;
    id: string;
    domId?: string;
    componentKey: string | React.ComponentType;
    onPointerMove: (evt: PointerEvent | MouseEvent) => void;
    onPointerDown: (evt: PointerEvent | MouseEvent) => void;
    onPointerUp: (evt: PointerEvent | MouseEvent) => void;
    onWheel: (evt: WheelEvent) => void;
    props?: Record<string, any>;
    data?: Serializable;
    unitId: string;
}
export declare class CanvasFloatDomService {
    private _domLayerMap;
    private _domLayers$;
    domLayers$: Observable<[string, IFloatDom][]>;
    get domLayers(): [string, IFloatDom][];
    private _notice;
    updateFloatDom(id: string, item: Partial<IFloatDom>): void;
    addFloatDom(item: IFloatDom): void;
    removeFloatDom(id: string): void;
    removeAll(): void;
}
