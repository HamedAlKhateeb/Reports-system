/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Nullable } from '@univerjs/core';
import type { IBoundRectNoAngle } from '@univerjs/engine-render';
import type { Observable } from 'rxjs';
import type { IRectPopupProps } from '../../views/components/popup/RectPopup';
import { Disposable } from '@univerjs/core';
export interface IPopup<T = Record<string, unknown>> extends Omit<IRectPopupProps, 'children' | 'hidden' | 'excludeRects' | 'anchorRect$'> {
    anchorRect$: Observable<IBoundRectNoAngle>;
    anchorRect?: IBoundRectNoAngle;
    excludeRects$?: Observable<IBoundRectNoAngle[]>;
    excludeRects?: Nullable<IBoundRectNoAngle[]>;
    componentKey: string;
    unitId: string;
    subUnitId: string;
    offset?: [number, number];
    canvasElement: HTMLCanvasElement;
    hideOnInvisible?: boolean;
    hiddenType?: 'hide' | 'destroy';
    hiddenRects$?: Observable<IBoundRectNoAngle[]>;
    extraProps?: T;
    customActive?: boolean;
    onActiveChange?: (active: boolean) => void;
}
export interface ICanvasPopupService {
    addPopup(item: IPopup): string;
    removePopup(id: string): void;
    removeAll(): void;
    popups$: Observable<[string, IPopup][]>;
    get popups(): [string, IPopup][];
    /**
     * which popup is under hovering now
     */
    get activePopupId(): Nullable<string>;
}
export declare const ICanvasPopupService: import("@wendellhu/redi").IdentifierDecorator<ICanvasPopupService>;
export declare class CanvasPopupService extends Disposable implements ICanvasPopupService {
    private readonly _popupMap;
    private readonly _popups$;
    readonly popups$: Observable<[string, IPopup<Record<string, unknown>>][]>;
    get popups(): [string, IPopup<Record<string, unknown>>][];
    private _activePopupId;
    get activePopupId(): Nullable<string>;
    private _update;
    dispose(): void;
    addPopup(item: IPopup): string;
    removePopup(id: string): void;
    removeAll(): void;
}
