/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { FEnum } from '@univerjs/core/facade';
import { SHEET_VIEWPORT_KEY } from '@univerjs/engine-render';
/**
 * @ignore
 */
export interface IFSheetsUIEnumMixin {
    /**
     * Sheet value change command types. These commands affect the content or style of cells.
     * Includes operations like setting cell values, moving ranges, merging cells, and applying styles.
     */
    SHEET_VIEWPORT_KEY: typeof SHEET_VIEWPORT_KEY;
}
export declare class FSheetsUIEnumMixin extends FEnum implements IFSheetsUIEnumMixin {
    get SHEET_VIEWPORT_KEY(): typeof SHEET_VIEWPORT_KEY;
}
declare module '@univerjs/core/facade' {
    interface FEnum extends IFSheetsUIEnumMixin {
    }
}
