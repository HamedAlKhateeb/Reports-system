/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IDisposable, IPosition, ISelectionCell, Nullable } from '@univerjs/core';
import type { Engine, IDocumentLayoutObject, Scene } from '@univerjs/engine-render';
import type { KeyCode } from '@univerjs/ui';
import type { Observable } from 'rxjs';
import { Disposable, IContextService, IUniverInstanceService, TextDirection, ThemeService } from '@univerjs/core';
import { IEditorService } from '@univerjs/docs-ui';
import { DeviceInputEventType, IRenderManagerService } from '@univerjs/engine-render';
import { SheetInterceptorService, SheetSkeletonService } from '@univerjs/sheets';
import { BehaviorSubject } from 'rxjs';
export interface IEditorBridgeServiceVisibleParam {
    visible: boolean;
    eventType: DeviceInputEventType;
    unitId: string;
    keycode?: KeyCode;
}
export interface ICurrentEditCellParam {
    scene: Scene;
    engine: Engine;
    unitId: string;
    sheetId: string;
    primary: ISelectionCell;
}
export interface ICellEditorState {
    unitId: string;
    sheetId: string;
    row: number;
    column: number;
    documentLayoutObject: IDocumentLayoutObject;
    editorUnitId: string;
    isInArrayFormulaRange?: Nullable<boolean>;
}
export interface ICellEditorLayout {
    position: IPosition;
    canvasOffset: {
        left: number;
        top: number;
    };
    scaleX: number;
    scaleY: number;
}
export interface IEditorBridgeServiceParam extends ICellEditorState, ICellEditorLayout {
}
export interface IEditorBridgeService {
    currentEditCellState$: Observable<Nullable<ICellEditorState>>;
    currentEditCellLayout$: Observable<Nullable<ICellEditorLayout>>;
    currentEditCell$: Observable<Nullable<IEditorBridgeServiceParam>>;
    visible$: Observable<IEditorBridgeServiceVisibleParam>;
    forceKeepVisible$: Observable<boolean>;
    /**
     * Stream of the *effective* text direction for the active cell editor.
     * Re-evaluates whenever the editor's body content changes (typing, paste,
     * delete) so the wrapper `<div dir>`, the hidden contenteditable, the
     * cell-editor resize math, and the canvas paragraph alignment can all
     * react in real time.
     *
     * Resolution order:
     *  1. The cell's explicit `style.td`.
     *  2. First-strong character in the live editor body.
     *  3. LTR fallback.
     */
    effectiveTextDirection$: Observable<TextDirection>;
    dispose(): void;
    refreshEditCellState(): void;
    refreshEditCellPosition(resetSizeOnly?: boolean): void;
    setEditCell(param: ICurrentEditCellParam): void;
    getEditCellState(): Readonly<Nullable<IEditorBridgeServiceParam>>;
    getEditCellLayout(): Readonly<Nullable<ICellEditorLayout>>;
    getEditLocation(): Readonly<Nullable<ICellEditorState>>;
    updateEditLocation(row: number, col: number): void;
    getLatestEditCellState(): Readonly<Nullable<IEditorBridgeServiceParam>>;
    /**
     * @deprecated do not use it directly, use command SetCellEditVisibleOperation as instead.
     */
    changeVisible(param: IEditorBridgeServiceVisibleParam): void;
    changeEditorDirty(dirtyStatus: boolean): void;
    getEditorDirty(): boolean;
    isVisible(): IEditorBridgeServiceVisibleParam;
    enableForceKeepVisible(): void;
    disableForceKeepVisible(): void;
    isForceKeepVisible(): boolean;
    getCurrentEditorId(): string;
    helpFunctionVisible$: BehaviorSubject<boolean>;
    /**
     * Recompute the cell editor's effective text direction based on the
     * **live** content in the editor docs unit, write it back into the
     * editor's `documentStyle.renderConfig.textDirection` and per-paragraph
     * `paragraphStyle.direction`, and emit on `effectiveTextDirection$`.
     *
     * Call this on every keystroke / RichTextEditingMutation so the
     * direction tracks reality (e.g. empty → Arabic flips to RTL, deleting
     * back to ASCII flips to LTR).
     */
    syncEditorTextDirection(): void;
    getEffectiveTextDirection(): TextDirection;
}
export declare class EditorBridgeService extends Disposable implements IEditorBridgeService, IDisposable {
    private readonly _sheetInterceptorService;
    private readonly _sheetSkeletonService;
    private readonly _renderManagerService;
    private readonly _themeService;
    private readonly _univerInstanceService;
    private readonly _editorService;
    private readonly _contextService;
    private _editorUnitId;
    private _editorIsDirty;
    private _visibleParams;
    private _currentEditCell;
    private _currentEditCellState;
    private _currentEditCellLayout;
    helpFunctionVisible$: BehaviorSubject<boolean>;
    private readonly _currentEditCellState$;
    readonly currentEditCellState$: Observable<Nullable<ICellEditorState>>;
    private readonly _currentEditCellLayout$;
    readonly currentEditCellLayout$: Observable<Nullable<ICellEditorLayout>>;
    readonly currentEditCell$: Observable<{
        position: IPosition;
        canvasOffset: {
            left: number;
            top: number;
        };
        scaleX: number;
        scaleY: number;
        unitId: string;
        sheetId: string;
        row: number;
        column: number;
        documentLayoutObject: IDocumentLayoutObject;
        editorUnitId: string;
        isInArrayFormulaRange?: Nullable<boolean>;
    } | null>;
    private readonly _visibleParams$;
    readonly visible$: Observable<IEditorBridgeServiceVisibleParam>;
    private readonly _afterVisibleParams$;
    readonly afterVisible$: Observable<IEditorBridgeServiceVisibleParam>;
    private readonly _forceKeepVisible$;
    readonly forceKeepVisible$: Observable<boolean>;
    private readonly _effectiveTextDirection$;
    readonly effectiveTextDirection$: Observable<TextDirection>;
    constructor(_sheetInterceptorService: SheetInterceptorService, _sheetSkeletonService: SheetSkeletonService, _renderManagerService: IRenderManagerService, _themeService: ThemeService, _univerInstanceService: IUniverInstanceService, _editorService: IEditorService, _contextService: IContextService);
    refreshEditCellState(): void;
    refreshEditCellPosition(resetSizeOnly?: boolean): void;
    setEditCell(param: ICurrentEditCellParam): void;
    private _clearCurrentEditCellState;
    getEditCellState(): Readonly<Nullable<IEditorBridgeServiceParam>>;
    getEditCellLayout(): Readonly<Nullable<ICellEditorLayout>>;
    getEditLocation(): Readonly<Nullable<ICellEditorState>>;
    updateEditLocation(row: number, column: number): void;
    getLatestEditCellState(): {
        position: {
            startX: number;
            startY: number;
            endX: number;
            endY: number;
        };
        scaleX: number;
        scaleY: number;
        canvasOffset: {
            left: number;
            top: number;
        };
        row: number;
        column: number;
        unitId: string;
        sheetId: string;
        documentLayoutObject: IDocumentLayoutObject;
        editorUnitId: string;
        isInArrayFormulaRange: Nullable<boolean>;
    } | undefined;
    getCurrentEditorId(): string;
    changeVisible(params: IEditorBridgeServiceVisibleParam): void;
    isVisible(): IEditorBridgeServiceVisibleParam;
    enableForceKeepVisible(): void;
    disableForceKeepVisible(): void;
    isForceKeepVisible(): boolean;
    changeEditorDirty(dirtyStatus: boolean): void;
    getEditorDirty(): boolean;
    getEffectiveTextDirection(): TextDirection;
    syncEditorTextDirection(): void;
    /**
     * Returns the cell's explicit `style.td` (LTR / RTL) when set, or
     * `undefined` when the cell has no direction set / is `UNSPECIFIED`.
     * Reads from the actual workbook so it can't be fooled by the renderConfig
     * value that was previously auto-derived from the seed content.
     */
    private _getEditCellExplicitTextDirection;
    /**
     * Concatenate the editor body's dataStream. We strip the trailing
     * sentinel paragraph break + chapter break that Univer always appends.
     */
    private _readEditorBodyText;
    /**
     * Push paragraph-level directions into the live editor docs unit so the
     * canvas pipeline (`_horizontalHandler`, `applyBidiReorderToLine`) and
     * `cell-editor-resize.service` `effectiveHorizontalAlign` math see the
     * same source of truth. Callers (`fitTextSize` / the React container)
     * handle the DOM-side `<div dir>` + contenteditable updates.
     *
     * @param explicitOverride When set, every paragraph and the document
     *   renderConfig get this single direction (cell-level explicit
     *   `style.td`). When `undefined`, each paragraph independently picks
     *   a direction from its own first-strong character — this is what
     *   makes mixed-direction list cells (Arabic bullet → English bullet)
     *   align each row correctly.
     * @returns The single "baseline" direction representing the whole
     *   cell, used by outer UI signals (`<div dir>`, resize math, the
     *   `effectiveTextDirection$` observable). Equals `explicitOverride`
     *   when set, otherwise the first paragraph's resolved direction
     *   (LTR fallback when the cell has no paragraphs / content).
     */
    private _applyEditorDirection;
}
export declare const IEditorBridgeService: import("@wendellhu/redi").IdentifierDecorator<IEditorBridgeService>;
