/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IUniverDocsUIConfig } from './config/config';
import { ICommandService, IConfigService, ILogService, Injector, Plugin } from '@univerjs/core';
import { IRenderManagerService } from '@univerjs/engine-render';
export declare class UniverDocsUIPlugin extends Plugin {
    private readonly _config;
    _injector: Injector;
    private readonly _renderManagerSrv;
    private _commandService;
    private _logService;
    private readonly _configService;
    static pluginName: string;
    static packageName: string;
    static version: string;
    constructor(_config: Partial<IUniverDocsUIConfig> | undefined, _injector: Injector, _renderManagerSrv: IRenderManagerService, _commandService: ICommandService, _logService: ILogService, _configService: IConfigService);
    onReady(): void;
    onRendered(): void;
    private _initCommand;
    private _initializeShortcut;
    private _initDependencies;
    private _markDocAsFocused;
    private _initRenderBasics;
    private _initRenderModules;
}
