/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DocumentDataModel, IDocumentData } from '@univerjs/core';
import { ICommandService, Injector, IResourceManagerService, IUniverInstanceService } from '@univerjs/core';
import { IRenderManagerService } from '@univerjs/engine-render';
export interface IDocumentInsertTextFacadeOptions {
    startOffset?: number;
    endOffset?: number;
    segmentId?: string;
    cursorOffset?: number;
}
/**
 * @hideconstructor
 */
export declare class FDocument {
    private readonly _documentDataModel;
    protected readonly _injector: Injector;
    private readonly _univerInstanceService;
    private readonly _commandService;
    private readonly _resourceManagerService;
    private readonly _renderManagerService;
    readonly id: string;
    constructor(_documentDataModel: DocumentDataModel, _injector: Injector, _univerInstanceService: IUniverInstanceService, _commandService: ICommandService, _resourceManagerService: IResourceManagerService, _renderManagerService: IRenderManagerService);
    getId(): string;
    getName(): string;
    getSnapshot(): IDocumentData;
    undo(): Promise<boolean>;
    redo(): Promise<boolean>;
    /**
     * Adds the specified text to the end of this text region.
     * @param text - The text to be added to the end of this text region.
     */
    appendText(text: string): Promise<boolean>;
    /**
     * Inserts text at the provided document range. Defaults to appending before the final section break.
     * @param text - The text to insert.
     * @param options - Optional target range, segment id, and cursor offset.
     */
    insertText(text: string, options?: IDocumentInsertTextFacadeOptions): Promise<boolean>;
    /**
     * Inserts one or more plain-text paragraphs at the provided document range.
     * @param text - Paragraph text. Newlines are normalized to document paragraph separators.
     * @param options - Optional target range, segment id, and cursor offset.
     */
    insertParagraph(text?: string, options?: IDocumentInsertTextFacadeOptions): Promise<boolean>;
    /**
     * Sets the selection to a specified text range in the document.
     * @param startOffset - The starting offset of the selection in the document.
     * @param endOffset - The ending offset of the selection in the document.
     * @example
     * ```typescript
     * document.setSelection(10, 20);
     * ```
     */
    setSelection(startOffset: number, endOffset: number): void;
}
