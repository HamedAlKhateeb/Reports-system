/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Editor } from '../../../services/editor/editor';
import { KeyCode, MetaKeys } from '@univerjs/ui';
export interface IUseLeftAndRightArrowOptions {
    /**
     * Force a writing direction for arrow-key mapping regardless of the
     * editor's paragraph direction. Used e.g. by the formula bar to lock
     * LTR behaviour even when the surrounding sheet / cell is RTL.
     */
    forceDirection?: 'ltr' | 'rtl';
}
export declare const useLeftAndRightArrow: (isNeed: boolean, selectingMode: boolean, editor?: Editor, onMoveInEditor?: (keyCode: KeyCode, metaKey?: MetaKeys) => void, options?: IUseLeftAndRightArrowOptions) => void;
